
1.0.1 / 2016-06-23
==================

  * fix: print more server connections log (#9)
  * fix: ignore GRACEFUL_COV env

1.0.0 / 2014-11-05
==================

 * refator: use express instead connect on example

0.1.0 / 2014-05-29
==================

 * send disconnect message

0.0.6 / 2014-02-17 
==================

  * add console.error(err.stack) by default (@dead-horse)
  * add npm image
  * support coveralls

0.0.5 / 2013-04-18 
==================

  * fixed header sent bug

0.0.4 / 2013-04-18 
==================

  * add options.worker
  * add custom error log demo

0.0.3 / 2013-04-14 
==================

  * Let http server set `Connection: close` header, and close the current request socket. fixed #2

0.0.2 / 2013-04-14 
==================

  * Support multi servers close fixed #1
  * update readme

0.0.1 / 2013-04-12 
==================

  * first commit
