
1.2.1 / 2017-05-19
==================

  * fix: package.json to reduce vulnerabilities (#3)

1.2.0 / 2016-05-21
==================

  * feat: warn with stack

1.1.0 / 2016-04-04
==================

  * deps: upgrade ms to 0.7.0

1.0.1 / 2014-12-31
==================

  * feat(index.js): warn when result is undefined

1.0.0 / 2014-08-14
==================

  * init
