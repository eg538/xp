
1.1.0 / 2018-01-17
==================

**features**
  * [[`180028b`](http://github.com/node-modules/graceful-process/commit/180028be79b2d55ac3142e24b272f7552f3bbb25)] - feat: add logLevel to control print log level (#3) (fengmk2 <<fengmk2@gmail.com>>)

**others**
  * [[`7edd157`](http://github.com/node-modules/graceful-process/commit/7edd1578ad15264b1e7e8395ffbeb174865694e6)] - test: add more assert on tests (#2) (fengmk2 <<fengmk2@gmail.com>>)
  * [[`b838376`](http://github.com/node-modules/graceful-process/commit/b838376b42a239c9d8a61a4e3ce0b167d327119b)] - deps: use nyc version of egg-bin (#1) (fengmk2 <<fengmk2@gmail.com>>)

1.0.0 / 2017-06-12
==================

  * first release
