2.1.1 / 2015-09-20
==================

  * Use correct SPDX license.
  * Test "browser.js" using browserify.
  * Switch from "envify" to "loose-envify".

2.1.0 / 2015-06-03
==================

  * Add "envify" as a dependency.
  * Fixed license field in "package.json".

2.0.0 / 2015-02-21
==================

  * Switch to using the "browser" field. There are now browser and server versions that respect the "format" in production.

1.0.2 / 2014-09-24
==================

  * Added tests, npmignore and gitignore.
  * Clarifications in README.

1.0.1 / 2014-09-24
==================

  * Actually include 'invariant.js'.

1.0.0 / 2014-09-24
==================

  * Initial release.
