<?php

  sleep(5)

?>