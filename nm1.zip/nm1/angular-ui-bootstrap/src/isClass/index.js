require('./isClass');

var MODULE_NAME = 'ui.bootstrap.module.isClass';

angular.module(MODULE_NAME, ['ui.bootstrap.isClass']);

module.exports = MODULE_NAME;
