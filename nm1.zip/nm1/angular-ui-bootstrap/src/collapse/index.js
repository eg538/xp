require('./collapse');

var MODULE_NAME = 'ui.bootstrap.module.collapse';

angular.module(MODULE_NAME, ['ui.bootstrap.collapse']);

module.exports = MODULE_NAME;
