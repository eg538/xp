# angular-es6-d3

Component to use: `pie-chart`


Example:
```
npm i
npm start
```

Example image:

![Pie Chart](img/pie.png)

![Donut Chart](img/donut.png)

Please refer to [assets/](assets/) directory for examples
