require('./dist/angular-es6-d3');
module.exports = 'angular.es6.d3';
