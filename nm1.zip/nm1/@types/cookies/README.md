# Installation
> `npm install --save @types/cookies`

# Summary
This package contains type definitions for cookies (https://github.com/pillarjs/cookies).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/cookies

Additional Details
 * Last updated: Mon, 30 Oct 2017 19:05:37 GMT
 * Dependencies: http, keygrip, express, connect, node
 * Global values: none

# Credits
These definitions were written by Wang Zishi <https://github.com/WangZishi>, jKey Lu <https://github.com/jkeylu>, BendingBender <https://github.com/BendingBender>.
