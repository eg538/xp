# Installation
> `npm install --save @types/d3-selection`

# Summary
This package contains type definitions for D3JS d3-selection module (https://github.com/d3/d3-selection/).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/d3-selection

Additional Details
 * Last updated: Thu, 23 Feb 2017 15:22:19 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Tom Wanzek <https://github.com/tomwanzek>, Alex Ford <https://github.com/gustavderdrache>, Boris Yankov <https://github.com/borisyankov>.
