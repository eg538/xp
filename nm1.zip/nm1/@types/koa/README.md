# Installation
> `npm install --save @types/koa`

# Summary
This package contains type definitions for Koa (http://koajs.com).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/koa

Additional Details
 * Last updated: Thu, 14 Dec 2017 21:33:44 GMT
 * Dependencies: accepts, cookies, events, http, http-assert, keygrip, koa-compose, net, url, node
 * Global values: none

# Credits
These definitions were written by DavidCai1993 <https://github.com/DavidCai1993>, jKey Lu <https://github.com/jkeylu>, Brice Bernard <https://github.com/brikou>.
