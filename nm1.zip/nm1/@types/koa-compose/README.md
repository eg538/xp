# Installation
> `npm install --save @types/koa-compose`

# Summary
This package contains type definitions for koa-compose (https://github.com/koajs/compose).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/koa-compose

Additional Details
 * Last updated: Mon, 27 Mar 2017 18:23:19 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by jKey Lu <https://github.com/jkeylu>.
