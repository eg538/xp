# Installation
> `npm install --save @types/body-parser`

# Summary
This package contains type definitions for body-parser (https://github.com/expressjs/body-parser).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/body-parser

Additional Details
 * Last updated: Wed, 08 Nov 2017 22:15:33 GMT
 * Dependencies: express, node
 * Global values: none

# Credits
These definitions were written by Santi Albo <https://github.com/santialbo>, Vilic Vane <https://github.com/vilic>, Jonathan Häberle <https://github.com/dreampulse>, Gevik Babakhani <https://github.com/blendsdk>, Tomasz Łaziuk <https://github.com/tlaziuk>.
