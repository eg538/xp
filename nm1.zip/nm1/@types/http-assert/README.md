# Installation
> `npm install --save @types/http-assert`

# Summary
This package contains type definitions for http-assert (https://github.com/jshttp/http-assert).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/http-assert

Additional Details
 * Last updated: Thu, 09 Nov 2017 08:43:07 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by jKey Lu <https://github.com/jkeylu>.
