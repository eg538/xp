# Installation
> `npm install --save @types/koa-router`

# Summary
This package contains type definitions for koa-router (https://github.com/alexmingoia/koa-router/).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/koa-router

Additional Details
 * Last updated: Sun, 03 Dec 2017 16:26:41 GMT
 * Dependencies: koa
 * Global values: none

# Credits
These definitions were written by Jerry Chin <https://github.com/hellopao>, Pavel Ivanov <https://github.com/schfkt>.
