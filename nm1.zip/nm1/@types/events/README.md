# Installation
> `npm install --save @types/events`

# Summary
This package contains type definitions for events (https://github.com/Gozala/events).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/events

Additional Details
 * Last updated: Sun, 03 Dec 2017 16:26:41 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Yasunori Ohoka <https://github.com/yasupeke>.
