# Installation
> `npm install --save @types/connect`

# Summary
This package contains type definitions for connect (https://github.com/senchalabs/connect).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/connect

Additional Details
 * Last updated: Mon, 21 Aug 2017 21:49:18 GMT
 * Dependencies: http, node
 * Global values: none

# Credits
These definitions were written by Maxime LUCE <https://github.com/SomaticIT>.
