# Installation
> `npm install --save @types/express`

# Summary
This package contains type definitions for Express (http://expressjs.com).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/express

Additional Details
 * Last updated: Wed, 20 Dec 2017 14:50:50 GMT
 * Dependencies: body-parser, serve-static, express-serve-static-core
 * Global values: none

# Credits
These definitions were written by Boris Yankov <https://github.com/borisyankov>.
